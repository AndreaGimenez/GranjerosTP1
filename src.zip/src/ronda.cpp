/*
 * ronda.cpp
 *
 *  Created on: 29 Apr 2018
 *      Author: A
 */
#include "ronda.h"
#include "utilidades.h"

Ronda::Ronda(){
	this->primerJugador = 0 ;
	this->jugadorActual = 0 ;
	this->ultimoJugador = 0 ;
}

bool Ronda::estaAlFinal() {
	return (this->jugadorActual->verSiguiente()|| this->jugadorActual == 0);
}

bool Ronda::estaVacia(){
	return this->jugadorActual == 0;
}

Jugador* Ronda::verPrimerJugador(){

	return this->primerJugador ;

}

Jugador* Ronda::verJugadorActual(){

	return this->jugadorActual ;

}

void Ronda::agregarJugador(Jugador* nuevoJugador){

	if(this->estaVacia()){
		this->primerJugador = nuevoJugador ;
		this->ultimoJugador = nuevoJugador ;
		this->jugadorActual = nuevoJugador ;
	}
	else{
		this->ultimoJugador->cambiarSiguiente(nuevoJugador);
		this->ultimoJugador = nuevoJugador ;
	}
}

void Ronda::avanzarJugador(){

	if(this->estaAlFinal()){
		this->jugadorActual = primerJugador ;
	}
	else{
		this->jugadorActual = jugadorActual->verSiguiente();
	}

}

Ronda::~Ronda(){

	while(!this->estaVacia()){

		Jugador* jugadorAuxiliar = this->primerJugador;
		this->primerJugador = this->primerJugador->verSiguiente();
		delete jugadorAuxiliar;

	}
}

