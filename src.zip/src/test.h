/*
 * test.h
 *
 *  Created on: 27 abr. 2018
 *      Author: administrador
 */

#ifndef TEST_H_
#define TEST_H_

/*
 * Para testear =)
 */
class Test {
public:
	static void correrTests();
	static void testParametros();
	static void testAlmacen();
};

#endif /* TEST_H_ */
