/*
 * ronda.h
 *
 *  Created on: 20 Apr 2018
 *      Author: Andrea
 */

#ifndef RONDA_H_
#define RONDA_H_

#include "jugador.h"

class Ronda{

	private:
		Jugador* primerJugador;
		Jugador* jugadorActual;
		Jugador* ultimoJugador;

	public:
		//Pre: -
		//Post: crea una ronda de vacia.
		Ronda();

		//Pre:
		//Post:
		~Ronda();

		//Pre: -
		//Post: Devuelve un puntero al primer jugador de la ronda. 
		//		Si no tiene jugadores devuelve un puntero a NULL. 
		Jugador* verPrimerJugador();

		//Pre: -
		//Post: Devuelve un puntero al jugador cuyo turno se está ejecutando
		Jugador* verJugadorActual();

		//Pre:
		//Post: Se agregó un nuevo jugador.
		void agregarJugador(Jugador* nuevoJugador);

		//Post: Avanza una posicion en la ronda. 
		//		Si se encontraba en la ultima posición vuelve al principio.
		void avanzarJugador();

		//Pre:
		//Post: Se eliminó el primer jugador de la ronda. 
		//		Si la ronda estaba vacia la accion queda sin efecto.
		void popJugador();

		//Pre:
		//Post: Si el jugadorActual es el último de la ronda devuelve true.
		bool estaAlFinal() ;

		//Pre:
		//Post: Si la referencia al primerJugador de la ronda es nula, devuelve true.
		bool estaVacia() ;
};



#endif /* RONDA_H_ */
