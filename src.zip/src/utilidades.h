/*
 * utilidades.h
 *
 *  Created on: 19 Apr 2018
 *      Author: Usuario
 */

#ifndef UTILIDADES_H_
#define UTILIDADES_H_

#define TERRENOS_INICIALES 1



#endif /* UTILIDADES_H_ */
