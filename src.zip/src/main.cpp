/*
 * main.cpp
 *
 *  Created on: 25 abr. 2018
 *      Author: administrador
 */

#include "test.h"
#include "granjeros.h"

using namespace std;

int main(){

	//Test::correrTests();
	Granjeros granjeros;
	granjeros.jugar();

	return 0;
}


